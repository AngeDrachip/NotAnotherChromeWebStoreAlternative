chrome.alarms.onAlarm.addListener((alarm) => {
    chrome.storage.local.get(["reminders"], (data) => {
        let reminders = data.reminders || [];
        const reminder = reminders.find(r => r.id === alarm.name);
        if (reminder) {
            chrome.notifications.create(reminder.id, {
                type: "basic",
                iconUrl: "images/icon48.png",
                title: "Rappel REMINDRE",
                message: reminder.text,
                priority: 2
            });

            // Supprimer le rappel après notification
            reminders = reminders.filter(r => r.id !== alarm.name);
            chrome.storage.local.set({ "reminders": reminders });
        }
    });
});

chrome.notifications.onClicked.addListener((notifId) => {
    chrome.storage.local.get(["reminders"], (data) => {
        let reminders = data.reminders || [];
        const reminder = reminders.find(r => r.id === notifId);
        if (reminder && reminder.url) {
            chrome.tabs.create({ url: reminder.url });
        }
    });
});
