document.addEventListener("DOMContentLoaded", function () {
    displayReminders();

    document.getElementById("addReminder").addEventListener("click", addReminder);
});

function addReminder() {
    const reminderText = document.getElementById("reminderText").value;
    const reminderTime = document.getElementById("reminderTime").value;
    let reminderUrl = document.getElementById("reminderUrl").value;

    if (!reminderText || !reminderTime) {
        alert("Veuillez remplir le texte et la date du rappel.");
        return;
    }

    if (reminderUrl && !reminderUrl.startsWith("http://") && !reminderUrl.startsWith("https://")) {
        reminderUrl = "https://" + reminderUrl;
    }

    const reminder = {
        id: Date.now().toString(),
        text: reminderText,
        time: reminderTime,
        url: reminderUrl || null
    };

    let reminders = JSON.parse(localStorage.getItem("reminders")) || [];
    reminders.push(reminder);
    localStorage.setItem("reminders", JSON.stringify(reminders));

    displayReminders();
    scheduleNotification(reminder);
}

function displayReminders() {
    const reminderList = document.getElementById("reminderList");
    reminderList.innerHTML = "";

    let reminders = JSON.parse(localStorage.getItem("reminders")) || [];
    reminders.forEach((reminder, index) => {
        const li = document.createElement("li");
        const span = document.createElement("span");
        span.textContent = `${reminder.text} - ${new Date(reminder.time).toLocaleString()}`;

        const removeButton = document.createElement("button");
        removeButton.textContent = "❌";
        removeButton.classList.add("remove-button");
        removeButton.addEventListener("click", function () {
            removeReminder(index);
        });

        li.appendChild(span);
        li.appendChild(removeButton);
        reminderList.appendChild(li);
    });
}

function removeReminder(index) {
    let reminders = JSON.parse(localStorage.getItem("reminders")) || [];
    reminders.splice(index, 1);
    localStorage.setItem("reminders", JSON.stringify(reminders));
    displayReminders();
}

function scheduleNotification(reminder) {
    const timeDifference = new Date(reminder.time).getTime() - Date.now();
    if (timeDifference > 0) {
        chrome.alarms.create(reminder.id, { when: Date.now() + timeDifference });
        chrome.storage.local.get(["reminders"], (data) => {
            let reminders = data.reminders || [];
            reminders.push(reminder);
            chrome.storage.local.set({ "reminders": reminders });
        });
    }
}

chrome.notifications.onClicked.addListener((notifId) => {
    let reminders = JSON.parse(localStorage.getItem("reminders")) || [];
    const reminder = reminders.find(r => r.id === notifId);
    if (reminder && reminder.url) {
        chrome.tabs.create({ url: reminder.url });
    }
});
