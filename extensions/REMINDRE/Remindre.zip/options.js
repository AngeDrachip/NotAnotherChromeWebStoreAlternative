document.getElementById("saveIcon").addEventListener("click", function() {
  const fileInput = document.getElementById("iconUpload");
  const statusText = document.getElementById("status");

  if (fileInput.files.length > 0) {
    const file = fileInput.files[0];
    const reader = new FileReader();

    reader.onloadend = function() {
      const iconData = reader.result;

      // Sauvegarder l'icône dans le stockage local
      chrome.storage.local.set({ customIcon: iconData }, function() {
        statusText.textContent = "Icône personnalisée enregistrée!";
      });
    };

    reader.readAsDataURL(file);
  } else {
    statusText.textContent = "Aucun fichier sélectionné.";
  }
});
