chrome.storage.sync.get("darkMode", (data) => {
  document.documentElement.style.filter = data.darkMode ? "invert(1) hue-rotate(180deg)" : "none";
});
