chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.sync.set({ darkMode: false });
});

chrome.storage.onChanged.addListener((changes) => {
  if (changes.darkMode) {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs.length > 0) {
        chrome.scripting.executeScript({
          target: { tabId: tabs[0].id },
          function: toggleDarkMode,
          args: [changes.darkMode.newValue]
        });
      }
    });
  }
});

function toggleDarkMode(enabled) {
  document.documentElement.style.filter = enabled ? "invert(1) hue-rotate(180deg)" : "none";
}

// content.js
chrome.storage.sync.get("darkMode", (data) => {
  document.documentElement.style.filter = data.darkMode ? "invert(1) hue-rotate(180deg)" : "none";
});
